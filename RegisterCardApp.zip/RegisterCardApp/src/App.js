
import CardRegisterForm from "./Componenets/CardRegisterForm";



function App() {
  const user = {
    name : "Sepideh",
    text: 'I hope you enjoy learning React!',
    
  };
  return (
  
    <div 
    style={{
      display: "flex",
      justifyContent: "left",
      // alignItems: "center",
      // 
      backgroundColor: "lightgrey"
    }}
    >
    
    < CardRegisterForm user = { user } />
    </div>
  );
}

export default App;
 