import { act } from 'react-dom/test-utils';
import React from 'react'
import ReactDOM from 'react-dom';
import '@testing-library/jest-dom';
import { fireEvent } from '@testing-library/react'

import FormBody from '../Componenets/FormBody'
import Greeting from '../Componenets/Greeting';
import Field from '../Componenets/Field.js'


let rootContainer;

beforeEach(() => {
  rootContainer = document.createElement("div");
  document.body.appendChild(rootContainer);
});

afterEach(() => {
  document.body.removeChild(rootContainer);
  rootContainer = null;
});

describe('render Greeting', () => {
    it('greeting should be Welcome', () => {
        act(() => {
            ReactDOM.render(<Greeting  greeting="Welcome"   /> , rootContainer);
          });
          const h1 = rootContainer.querySelector('h1');
          expect(h1).toHaveTextContent('Welcome');
    });

    it('greeting should be Welcome  User', () => {
        act(() => {
            ReactDOM.render(<Greeting  greeting="Welcome"  name="User" /> , rootContainer);
          });
          const h1 = rootContainer.querySelector('h1');
          expect(h1).toHaveTextContent('Welcome User');
    })
});

describe('render FormBody', () => {
    const user = {
        name : "Sepideh",
        text: 'enjoy React!',
        
      };

    it('check card number mask is working', () => {  
        act(() => {
            ReactDOM.render(<FormBody user = { user } /> , rootContainer);
          });
          const cardNumber = rootContainer.querySelector('input[name="creditCardNumber"] ');
          fireEvent.change(cardNumber, { target: { value: 'abd' } })
          expect(cardNumber.value).toBe("____-____-____-____")
    });

    it('check cvc mask is working', () => {  
        act(() => {
            ReactDOM.render(<FormBody user = { user } /> , rootContainer);
          });
          const cvc = rootContainer.querySelector('input[name="cvc"] ');
          fireEvent.change(cvc, { target: { value: 'abd' } })
          expect(cvc.value).toBe("___")
    });

    it('check cvc validation is working', () => {  
        act(() => {
            ReactDOM.render(<FormBody user = { user } /> , rootContainer);
          });
          const cvc = rootContainer.querySelector('input[name="cvc"] ');
          fireEvent.change(cvc, { target: { value: '99' } })
          expect(cvc.classList.contains('redBorder')).toBe(true);
          fireEvent.change(cvc, { target: { value: '999' } })
          expect(cvc.classList.contains('redBorder')).not.toBe(true);
    });


    it('submit button should be disabled', () => {
        act(() => {
            ReactDOM.render(<FormBody user = { user } /> , rootContainer);
          });
          const cardNumber = rootContainer.querySelector('input[name="creditCardNumber"] ');
          fireEvent.change(cardNumber, { target: { value: '9999-9999-9999-9999' } })

          const btn = rootContainer.querySelector('input[type="submit"]');
          expect(btn).toBeDisabled();
    });

    it('submit button should be enabled when all items are not filled', () => {  
        act(() => {
            ReactDOM.render(<FormBody user = { user } /> , rootContainer);
          });
          const btn = rootContainer.querySelector('input[type="submit"]');

          const cardNumber = rootContainer.querySelector('input[name="creditCardNumber"] ');
          fireEvent.change(cardNumber, { target: { value: '9999-9999-9999-9999' } })
          //expect(cardNumber.classList.contains('redBorder')).not.toBe(true);
          
          const cvc = rootContainer.querySelector('input[name="cvc"] ');
          fireEvent.change(cvc, { target: { value: '999' } });
          //expect(cvc.classList.contains('redBorder')).not.toBe(true);

          const expiryDate = rootContainer.querySelector('input[name="expiringDate"] ');
          fireEvent.change(expiryDate, { target: { value: '10/21' } });
          //expect(expiryDate.classList.contains('redBorder')).not.toBe(true);

          expect(btn).toBeEnabled();
    });

});





describe('render Field', () => {
    it('field should have value', () => {
        const container = document.createElement('div');
        act(() => {
            ReactDOM.render(       <Field
                cName = 'cvv' 
                name="cvc"
                type="text"
                mask = "999"
                validate={(val) =>   {return  !val.match('^[0-9]{3}$');  }}
               />
        , container);
          });
    })
});


