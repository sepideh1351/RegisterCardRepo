import React from 'react';
import FormHeader from './FormHeader';
import FormBody from './FormBody';
import Sidebar from "./sidebar";


function CardRegisterForm(props){
       
const user = {
    name : "Sepideh",
    text: 'enjoy React!',
    
  };
  return (
  
    <div id ="CardForm" className="cardForm" >
      <Sidebar pageWrapId={"FormHeader"} outerContainerId={"CardForm"} />
      <FormHeader />
      <FormBody user = { user } />

    </div>
      
        );
}

export default CardRegisterForm;