import React from "react";
import { slide as Menu } from "react-burger-menu";
import back from '../img/back1.png'

export default props => {
  return (
    <Menu {...props} customCrossIcon={ <img src={back} /> }>

      <a className="menu-item" href="/">
        Menu1
      </a>

      <a className="menu-item" href="/">
        Menu2
      </a>

    </Menu>
  );
};
