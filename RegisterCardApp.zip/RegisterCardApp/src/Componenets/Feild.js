import PropTypes from 'prop-types';
import React from 'react';
import InputMask from "react-input-mask";

class Field extends React.Component {
  //Using proptypes to validate the props that are passing through the props from component-form
//   static propTypes = {
//     placeholder: PropTypes.string,
//     name: PropTypes.string.isRequired,
//     type: PropTypes.string,
//     value: PropTypes.string,
//     onChange: PropTypes.func.isRequired,
//     validate: PropTypes.func,
//   };
  
  constructor(props) {
    super(props);
    this.state = {
        value: '',
        error: false,
    };
    this.onChange = this.onChange.bind(this);
  }

  onChange = (evt) => {
    const name = this.props.name;
    const fieldValue = evt.target.value;
    const fieldError = this.props.validate ? this.props.validate(fieldValue) : false;
    this.setState({ value : fieldValue, error: fieldError });
    this.props.onChange( name, fieldValue, fieldError );
  };

  render() {
    return (
      <div className={this.props.cName}>
        <label >{this.props.title}</label>
        <br/>
        <InputMask 
          className= {` ${this.state.error ? "redBorder" : ""}`}
          placeholder={this.props.placeholder}
          name ={this.props.name}
          type={this.props.type ? this.props.type : ''}
          value={this.state.value}
          onChange={this.onChange}
          mask= {this.props.mask}  
          //maskChar=" "
        />
        <br/>
      </div>
    );
  }
};

export default Field;