import React from 'react';

function FormHeader(props){
    return (
      < div id= "FormHeader">
        <h3 style={{marginLeft: "40px"}} >
          Register Card Form
        </h3>
        </div>
        );
}

export default FormHeader;