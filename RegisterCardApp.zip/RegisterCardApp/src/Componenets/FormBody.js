import React, { Component } from "react";
import Greeting from "./Greeting";
import Field from "./Feild";
import '../css/CardRegisterForm.css';
import logo from '../img/logo.png';


class FormBody extends Component {
    constructor(props) {
      super(props);
      this.state = {
        cardDetails:  {
            creditCardNumber: '',
            cvc: '',
            expiringDate: '',
           
        },
        cardDetilsErrors: {
          creditCardNumber: true,
          cvc: true,
          expiringDate: true,
        },
        submitDisabled: true
      };
  
      this.handleInputChange = this.handleInputChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  


    handleInputChange( name, value, error ) {
        const cardDetails = this.state.cardDetails;
        const cardDetilsErrors = this.state.cardDetilsErrors;
    
        cardDetails[name] = value;
        cardDetilsErrors[name] = error;
    
        this.setState({ cardDetails, cardDetilsErrors });

        const ds = Object.keys(cardDetilsErrors).every((k) => !cardDetilsErrors[k]);
        this.setState({ submitDisabled:!ds });
      }
    
      handleSubmit = (event) => {
        console.log(`
          Credit Card Number: ${this.state.cardDetails.creditCardNumber}
          CVC: ${this.state.cardDetails.cvc}
          Expiring Date : ${this.state.cardDetails.expiringDate}
      ` );
    
        event.preventDefault();
      }

    render() {
      return (
        <div id = "FormBody">
        <form onSubmit={this.handleSubmit}  >
          
         <Greeting id = "MYGreeting" greeting = "Welcome" name = {this.props.user.name} /> 
          <br/>  <br/> <br/> 

          <img src={logo} alt="logo" />


          <Field
            title = "Credit Card Number"
            id = "CreditCardNumber"
            placeholder= "9999-9999-9999-9999"
            name="creditCardNumber"
            type="text"
            value={this.state.credirCardNumber}
            onChange={this.handleInputChange} 
            mask = "9999-9999-9999-9999"
             validate  = {(val) => 
              {
                var dateformat = /^([0-9]{4})-([0-9]{4})-([0-9]{4})-([0-9]{4})$/;
                return !val.match(dateformat) ;
            }}
        />
        <br/>
      
        <Field
          title = "CVC"
          cName = 'cvv' 
          placeholder = "999"
          name="cvc"
          type="text"
          value={this.state.cvc}
          onChange={this.handleInputChange} 
          mask = "999"
          validate={(val) =>   {return  !val.match('^[0-9]{3}$');  }}
         />
        
      <Field
        cName = "expiryDate"
        title = "Expiry Date"
        placeholder = "MM/YY"
        name="expiringDate"
        type="text"
        value={this.state.expiringDate}
        onChange={this.handleInputChange} 
        mask = "99/99"
        validate  = {(val) => 
            {
            var dateformat = /^(0[1-9]|1[0-2])\/([0-9]{2})$/;
            return   !val.match(dateformat);
            
        }}
         />
    
        <br/>  <br/> <br/>
        <div style={{ textAlign : "center" }}>
          <input type="submit" value="Submit" disabled={this.state.submitDisabled} className = "submitButton" />
          </div>
        </form>
        </div>
      );
    }
  }

  export default FormBody;